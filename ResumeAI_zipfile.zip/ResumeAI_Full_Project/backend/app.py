from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
from werkzeug.utils import secure_filename
from PyPDF2 import PdfReader
from docx import Document
import os
import re

PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))
FRONTEND_FOLDER = os.path.abspath(os.path.join(PROJECT_ROOT, "..", "frontend"))

app = Flask(__name__)
CORS(app)

UPLOAD_FOLDER = os.path.join(PROJECT_ROOT, "uploads")
MAX_FILE_SIZE = 10 * 1024 * 1024

app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER
app.config["MAX_CONTENT_LENGTH"] = MAX_FILE_SIZE

os.makedirs(UPLOAD_FOLDER, exist_ok=True)


# ============================================================
# COMPANY DATABASE
# ============================================================

COMPANIES = {

    "Google": {
        "skills": [
            "Data Structures & Algorithms",
            "Machine Learning",
            "Cloud Computing",
            "SQL & Databases",
            "System Design"
        ],
        "keywords": [
            "python", "java", "c++", "machine learning",
            "deep learning", "data structures", "algorithms",
            "sql", "cloud", "aws", "system design",
            "tensorflow", "pytorch"
        ]
    },

    "Microsoft": {
        "skills": [
            "Data Structures & Algorithms",
            "Cloud Computing",
            "Azure",
            "Machine Learning",
            "System Design"
        ],
        "keywords": [
            "python", "java", "c++", "c#", "azure",
            "machine learning", "data structures",
            "algorithms", "sql", "cloud",
            "system design"
        ]
    },

    "Amazon": {
        "skills": [
            "Data Structures & Algorithms",
            "AWS Cloud",
            "Python",
            "SQL & Databases",
            "System Design"
        ],
        "keywords": [
            "python", "java", "c++", "aws", "cloud",
            "machine learning", "data structures",
            "algorithms", "sql", "database",
            "system design"
        ]
    },

    "Meta": {
        "skills": [
            "Data Structures & Algorithms",
            "Python",
            "Machine Learning",
            "React",
            "System Design"
        ],
        "keywords": [
            "python", "c++", "javascript", "react",
            "machine learning", "deep learning",
            "data structures", "algorithms", "sql",
            "system design"
        ]
    },

    "Apple": {
        "skills": [
            "Swift / Programming",
            "Data Structures",
            "Machine Learning",
            "System Design",
            "Software Engineering"
        ],
        "keywords": [
            "swift", "python", "c++", "machine learning",
            "data structures", "algorithms",
            "software engineering", "system design",
            "ios"
        ]
    },

    "Tesla": {
        "skills": [
            "Python",
            "Machine Learning",
            "Computer Vision",
            "Deep Learning",
            "Data Structures"
        ],
        "keywords": [
            "python", "c++", "machine learning",
            "deep learning", "computer vision",
            "opencv", "tensorflow", "pytorch",
            "data structures", "robotics"
        ]
    },

    "Netflix": {
        "skills": [
            "Python",
            "Machine Learning",
            "Cloud Computing",
            "Data Engineering",
            "System Design"
        ],
        "keywords": [
            "python", "java", "machine learning",
            "data science", "cloud", "aws",
            "data engineering", "sql",
            "system design", "microservices"
        ]
    },

    "Adobe": {
        "skills": [
            "Java / C++",
            "Machine Learning",
            "Data Structures",
            "Cloud Computing",
            "Software Engineering"
        ],
        "keywords": [
            "java", "c++", "python",
            "machine learning", "data structures",
            "algorithms", "cloud", "sql",
            "software engineering"
        ]
    },

    "Infosys": {
        "skills": [
            "Programming",
            "Java / Python",
            "SQL",
            "Cloud Computing",
            "Communication Skills"
        ],
        "keywords": [
            "python", "java", "c", "c++", "sql",
            "database", "cloud", "machine learning",
            "communication", "problem solving"
        ]
    },

    "Oracle": {
        "skills": [
            "SQL & Databases",
            "Java",
            "Cloud Computing",
            "Data Structures",
            "System Design"
        ],
        "keywords": [
            "java", "python", "sql", "oracle",
            "database", "cloud", "data structures",
            "algorithms", "system design"
        ]
    }
}


# ============================================================
# FILE TEXT EXTRACTION
# ============================================================

def extract_pdf_text(filepath):

    text = ""

    try:
        reader = PdfReader(filepath)

        for page in reader.pages:
            page_text = page.extract_text()

            if page_text:
                text += page_text + "\n"

    except Exception as e:
        print("PDF error:", e)

    return text


def extract_docx_text(filepath):

    text = ""

    try:
        document = Document(filepath)

        for paragraph in document.paragraphs:
            text += paragraph.text + "\n"

    except Exception as e:
        print("DOCX error:", e)

    return text


def extract_resume_text(filepath):

    extension = filepath.lower().split(".")[-1]

    if extension == "pdf":
        return extract_pdf_text(filepath)

    if extension == "docx":
        return extract_docx_text(filepath)

    if extension == "doc":
        return ""

    return ""


# ============================================================
# TEXT PROCESSING
# ============================================================

def clean_text(text):

    text = text.lower()

    text = re.sub(
        r"[^a-z0-9+#.\s]",
        " ",
        text
    )

    text = re.sub(
        r"\s+",
        " ",
        text
    )

    return text


# ============================================================
# SKILL DETECTION
# ============================================================

def detect_skills(text):

    cleaned = clean_text(text)

    all_keywords = set()

    for company in COMPANIES.values():

        for keyword in company["keywords"]:
            all_keywords.add(keyword)

    detected = []

    for keyword in all_keywords:

        pattern = r"\b" + re.escape(
            keyword.lower()
        ) + r"\b"

        if re.search(pattern, cleaned):
            detected.append(keyword)

    return sorted(set(detected))


# ============================================================
# COMPANY SCORE
# ============================================================

def calculate_company_score(
    resume_text,
    company
):

    cleaned = clean_text(resume_text)

    keywords = COMPANIES[
        company
    ]["keywords"]

    matched = []

    for keyword in keywords:

        pattern = r"\b" + re.escape(
            keyword.lower()
        ) + r"\b"

        if re.search(pattern, cleaned):
            matched.append(keyword)

    if not keywords:
        return 0, []

    score = round(
        len(matched) /
        len(keywords) *
        100
    )

    return score, matched


# ============================================================
# OVERALL SCORE
# ============================================================

def calculate_overall_score(resume_text):

    scores = {}

    for company in COMPANIES:

        score, _ = calculate_company_score(
            resume_text,
            company
        )

        scores[company] = score

    if not scores:
        return 0, {}

    overall_score = round(
        sum(scores.values()) /
        len(scores)
    )

    return overall_score, scores


# ============================================================
# AI SUGGESTIONS
# ============================================================

def generate_suggestions(
    company,
    score,
    matched_skills
):

    required_skills = COMPANIES[
        company
    ]["skills"]

    suggestions = []

    if score < 50:

        suggestions.append(
            f"Your current profile has a low "
            f"match with {company}. Focus on "
            f"the core technical skills required "
            f"for this company."
        )

    elif score < 75:

        suggestions.append(
            f"Your profile has a moderate match "
            f"with {company}. Adding relevant "
            f"projects and technical skills can "
            f"improve your score."
        )

    else:

        suggestions.append(
            f"Your profile has a strong match "
            f"with {company}. Continue improving "
            f"your projects, problem-solving "
            f"skills and interview preparation."
        )

    matched_text = " ".join(
        matched_skills
    ).lower()

    missing = []

    for skill in required_skills:

        words = skill.lower().split()

        if not any(
            word in matched_text
            for word in words
        ):
            missing.append(skill)

    if missing:

        suggestions.append(
            "Recommended areas to improve: "
            + ", ".join(missing[:3])
            + "."
        )

    return " ".join(suggestions)


# ============================================================
# HOME API
# ============================================================

@app.route("/", methods=["GET"])
def home():
    return send_from_directory(FRONTEND_FOLDER, "index.html")


@app.route("/api/health", methods=["GET"])
def health():
    return jsonify({
        "application": "ResumeAI",
        "status": "running",
        "message": "ResumeAI backend is working successfully"
    })


# ============================================================
# RESUME ANALYSIS API
# ============================================================

@app.route(
    "/api/analyze",
    methods=["POST"]
)
def analyze_resume():

    if "resume" not in request.files:

        return jsonify({
            "success": False,
            "message": "No resume file uploaded."
        }), 400

    file = request.files["resume"]

    if file.filename == "":

        return jsonify({
            "success": False,
            "message": "No file selected."
        }), 400

    allowed = [
        "pdf",
        "doc",
        "docx"
    ]

    extension = (
        file.filename
        .lower()
        .split(".")[-1]
    )

    if extension not in allowed:

        return jsonify({
            "success": False,
            "message":
                "Only PDF, DOC and DOCX "
                "files are supported."
        }), 400

    filename = secure_filename(
        file.filename
    )

    filepath = os.path.join(
        UPLOAD_FOLDER,
        filename
    )

    file.save(filepath)

    resume_text = extract_resume_text(
        filepath
    )

    if not resume_text.strip():

        return jsonify({
            "success": False,
            "message":
                "Unable to extract text "
                "from the resume."
        }), 400

    detected_skills = detect_skills(
        resume_text
    )

    overall_score, company_scores = \
        calculate_overall_score(
            resume_text
        )

    sorted_companies = sorted(
        company_scores.items(),
        key=lambda x: x[1],
        reverse=True
    )

    top_companies = []

    for company, score in \
            sorted_companies[:5]:

        top_companies.append({
            "company": company,
            "score": score
        })

    return jsonify({

        "success": True,

        "filename": file.filename,

        "overall_score": overall_score,

        "detected_skills":
            detected_skills,

        "top_companies":
            top_companies,

        "all_company_scores":
            company_scores
    })


# ============================================================
# TARGET COMPANY ANALYSIS API
# ============================================================

@app.route(
    "/api/company/<company_name>",
    methods=["POST"]
)
def company_analysis(company_name):

    if company_name not in COMPANIES:

        return jsonify({
            "success": False,
            "message":
                "Company not found."
        }), 404

    if "resume" not in request.files:

        return jsonify({
            "success": False,
            "message":
                "Resume is required."
        }), 400

    file = request.files["resume"]

    filename = secure_filename(
        file.filename
    )

    filepath = os.path.join(
        UPLOAD_FOLDER,
        filename
    )

    file.save(filepath)

    resume_text = extract_resume_text(
        filepath
    )

    if not resume_text.strip():

        return jsonify({
            "success": False,
            "message":
                "Unable to read resume."
        }), 400

    score, matched_skills = \
        calculate_company_score(
            resume_text,
            company_name
        )

    required_skills = COMPANIES[
        company_name
    ]["skills"]

    suggestions = generate_suggestions(
        company_name,
        score,
        matched_skills
    )

    return jsonify({

        "success": True,

        "company":
            company_name,

        "score":
            score,

        "required_skills":
            required_skills,

        "matched_skills":
            matched_skills,

        "suggestion":
            suggestions
    })


# ============================================================
# GET ALL COMPANIES
# ============================================================

@app.route(
    "/api/companies",
    methods=["GET"]
)
def get_companies():

    result = {}

    for company, data \
            in COMPANIES.items():

        result[company] = {
            "skills":
                data["skills"]
        }

    return jsonify({
        "success": True,
        "companies": result
    })


# ============================================================
# DELETE UPLOADED FILE
# ============================================================

@app.route(
    "/api/clear",
    methods=["POST"]
)
def clear_uploads():

    deleted = 0

    for filename in os.listdir(
        UPLOAD_FOLDER
    ):

        filepath = os.path.join(
            UPLOAD_FOLDER,
            filename
        )

        try:

            if os.path.isfile(filepath):

                os.remove(filepath)

                deleted += 1

        except Exception as e:

            print(
                "Delete error:",
                e
            )

    return jsonify({

        "success": True,

        "message":
            f"{deleted} file(s) removed."
    })


# ============================================================
# ERROR HANDLERS
# ============================================================

@app.errorhandler(
    413
)
def file_too_large(error):

    return jsonify({

        "success": False,

        "message":
            "File is too large. "
            "Maximum size is 10 MB."
    }), 413


@app.errorhandler(
    404
)
def not_found(error):

    return jsonify({

        "success": False,

        "message":
            "API endpoint not found."
    }), 404


@app.errorhandler(
    500
)
def server_error(error):

    return jsonify({

        "success": False,

        "message":
            "Internal server error."
    }), 500


# ============================================================
# START SERVER
# ============================================================

if __name__ == "__main__":

    print()
    print("=" * 55)
    print("              ResumeAI Backend")
    print("=" * 55)
    print()
    print("Server running at:")
    print("http://127.0.0.1:5000")
    print()
    print("Resume Analysis:")
    print("POST /api/analyze")
    print()
    print("Company Analysis:")
    print("POST /api/company/<company>")
    print()
    print("Companies:")
    print("GET /api/companies")
    print()
    print("=" * 55)
    print()

    app.run(
        host="0.0.0.0",
        port=5000,
        debug=True
    )