# ResumeAI – Resume Analysis and Company Matching System

ResumeAI is a web application that extracts skills from uploaded resumes, calculates keyword-based compatibility scores for selected companies, and provides suggestions for skill improvement.

## Features
- Upload PDF and DOCX resumes (maximum 10 MB).
- Extract resume text and identify technical keywords.
- Calculate overall and company-wise compatibility scores.
- Display the top five company matches.
- Show matched skills and improvement suggestions.

## Technology
- Frontend: HTML, CSS, JavaScript
- Backend: Python, Flask, Flask-CORS
- Document parsing: PyPDF2, python-docx

## Project structure
```text
ResumeAI_Full_Project/
├── backend/
│   ├── app.py
│   ├── requirements.txt
│   └── uploads/          # Created automatically; do not commit resumes
├── frontend/
│   └── index.html
├── .gitignore
└── README.md
```

## Run locally
1. Install Python 3.10 or later.
2. Open a terminal in the `backend` folder.
3. Create and activate a virtual environment (recommended).
4. Install dependencies:

   ```bash
   python -m pip install -r requirements.txt
   ```

5. Start the Flask server:

   ```bash
   python app.py
   ```

6. Open http://127.0.0.1:5000 in your browser.

## API endpoints
- `GET /api/health` – backend status
- `POST /api/analyze` – overall resume analysis
- `POST /api/company/<company_name>` – company-specific analysis
- `GET /api/companies` – supported companies
- `POST /api/clear` – clear uploaded files

## Scoring note
The current backend uses predefined company keyword lists and keyword matching. It is a rule-based scoring approach, not a trained machine-learning model. Scores are indicative and should not be treated as actual hiring decisions.

## Privacy
Do not upload real personal resumes to a public repository. The `.gitignore` excludes the backend upload folder and common resume document files.
